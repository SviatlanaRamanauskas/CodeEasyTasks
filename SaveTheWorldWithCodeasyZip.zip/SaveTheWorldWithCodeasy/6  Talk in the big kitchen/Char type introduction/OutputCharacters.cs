using System;

namespace CharType
{
    class Beginning
    {
        static void Main(string[] args)
        {
            char someChar = char.Parse(Console.ReadLine());
            Console.WriteLine(someChar);
        }
    }
}