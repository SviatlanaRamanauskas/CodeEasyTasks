using System;

namespace CharType
{
    class OneLine
    {
        static void Main(string[] args)
        {
            char theRealChar1 = char.Parse(Console.ReadLine());
            char theRealChar2 = char.Parse(Console.ReadLine());
            Console.Write(theRealChar1);
            Console.Write(theRealChar2);
        }
    }
}