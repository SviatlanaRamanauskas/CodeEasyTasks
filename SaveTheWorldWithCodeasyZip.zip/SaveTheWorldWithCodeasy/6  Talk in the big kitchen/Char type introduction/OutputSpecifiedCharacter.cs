using System;

namespace CharType
{
    class CharInTheString
    {
        static void Main(string[] args)
        {
            string someChar = Console.ReadLine();
            Console.WriteLine(someChar[1]);
        }
    }
}