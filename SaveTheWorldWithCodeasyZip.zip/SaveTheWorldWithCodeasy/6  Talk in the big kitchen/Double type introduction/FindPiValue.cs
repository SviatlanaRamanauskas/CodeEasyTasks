using System;

namespace DoubleType
{
    class Introduction
    {
        static void Main(string[] args)
        {
            double value = 3.14;
            Console.WriteLine($"Pi is close to {value}");
        }
    }
}
