using System;

public static class TurnOffDroids
{
    public static void Main()
    {
        // Write your code under this line

    }
}