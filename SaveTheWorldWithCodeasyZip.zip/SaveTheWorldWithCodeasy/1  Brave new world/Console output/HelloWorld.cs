/*using System;

public static class HelloWorld
{
    public static void Main()
    {
        Console.WriteLine("Paste text here. Don't forget to leave the quotes.");
    }
}*/