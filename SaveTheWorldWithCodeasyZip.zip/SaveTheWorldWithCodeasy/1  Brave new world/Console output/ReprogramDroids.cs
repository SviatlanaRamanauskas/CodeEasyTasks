using System;

public static class ReprogramDroids
{
    public static void Main()
    {
        // Write your code under this line

    }
}