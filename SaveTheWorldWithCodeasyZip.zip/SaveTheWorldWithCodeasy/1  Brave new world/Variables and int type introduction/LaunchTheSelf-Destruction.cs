/*using System;

public class LaunchSelfDestruction 
{
    public static void Main(string[] args)
    {
        // Write your code under this line

        Console.WriteLine("Self-destruction started. The code is");
        Console.WriteLine(code);
    }
}*/