using System;

public class KillTheDroid
{
    public static void Main(string[] args)
    {
        int half = 1005 + 5;
        int secondHalf = 500 / 2;
        int answer = half + secondHalf;

        Console.WriteLine("To prove that you are a machine please input the year when c# first appeared");
        Console.WriteLine(answer);
    }
}