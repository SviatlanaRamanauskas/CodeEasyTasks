using System;

public static class DrawToSafetyPlace
{
    public static void Main()
    {
        int result = 0;
        Console.WriteLine(result);
    }
}