using System;

namespace Arrays
{
    class FirstArray
    {
        public static void Main(string[] args)
        {
            int[] someNumbers = new int[5];
            Console.WriteLine(someNumbers[0]);
            Console.WriteLine(someNumbers[1]);
            Console.WriteLine(someNumbers[2]);
            Console.WriteLine(someNumbers[3]);
            Console.WriteLine(someNumbers[4]);
        }
    }
}