/*using System;
using System.Collections.Generic;

namespace Lists
{
    public class ListsAnimals
    {
        static void Main(string[] args)
        {
            List<string> animals = new List<string> { "Wolf", "Fish", "Elephant", "Dog" };
            foreach (string animal in animals)
                Console.WriteLine(animal);
        }
    }
}*/