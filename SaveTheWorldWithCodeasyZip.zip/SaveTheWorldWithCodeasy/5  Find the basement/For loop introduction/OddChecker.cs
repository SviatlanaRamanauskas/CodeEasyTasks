using System;

namespace ForLoops
{
    class Odd
    {
        static void Main(string[] args)
        {
            for (int i = 101; i < 201; i = i + 2)
            {
                Console.WriteLine(i);
            }// Write your code here
        }
    }
}
