using System;

namespace OutputAllNumbers
{
    class PasswordHack
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 100; i++)// Write your code here
            {
                Console.WriteLine(i);
            }
        }
    }
}
