using System;

namespace ForLoops
{
    class FirstUsage
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("for loop made my day!");// Write your code here
            }
        }
    }
}
