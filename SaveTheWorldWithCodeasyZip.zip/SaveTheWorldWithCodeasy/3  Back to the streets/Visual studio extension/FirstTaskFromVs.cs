using System;

namespace CodeasyExtension
{
    class FirstTaskFromVisualStudio
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I write code as professional programmers do!");
        }
    }
}
