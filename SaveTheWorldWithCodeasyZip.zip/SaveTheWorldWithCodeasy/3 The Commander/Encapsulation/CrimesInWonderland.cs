using System;

namespace Encapsulation
{
    class Good
    {
        public string Identifier { get; set; }
        private double _price;
        public double Price
        {
            get
            {
                return _price;
            }
            set
            {
                for (int i = 0; i < 1; i++)
                {
                    _price = value;
                }
            }
        }
    }

    class ClassWithMain
    {
        static void Main(string[] args)
        {
            var good = new Good
            {
                Identifier = Console.ReadLine(),
                Price = double.Parse(Console.ReadLine())
            };

            DecreasePrice(good);

            Console.WriteLine($"I can buy {good.Identifier} for {good.Price}.");
        }

        private static void DecreasePrice(Good good)
        {
            good.Price -= 1.0;
        }
    }
}