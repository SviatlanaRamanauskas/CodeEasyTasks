/*namespace Encapsulation
{
    class Elevator
    {
        public int CurrentFloor { get; set; }
        public int MaxFloor { get; set; }
        public int MinFloor { get; set; }
        public double Weight { get; set; }
        public string Manufacturer { get; set; }
    }

    class ClassWithMain
    {
        static void Main(string[] args)
        { }
    }
}*/