using System;

namespace Properties
{
    class Flower
    {
        public string Name { get; set; }
        public string Color { get; set; }
        public int Age { get; set; }
        public bool IsEndangered { get; set; }
    }
}