namespace AccessModifiers
{
    class ExtendedShield
    {
        private string _identifier;
        private int _power;

        public ExtendedShield(string identifier, int power)
        {
            _power = power;
            _identifier = identifier;
        }
    }
}