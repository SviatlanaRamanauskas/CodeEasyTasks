namespace AccessModifiers
{
    class Shield
    {
        private string _identifier;
        private int _power;

        public Shield()
        {
            _power = 10;
            _identifier = "Default";
        }
    }
}