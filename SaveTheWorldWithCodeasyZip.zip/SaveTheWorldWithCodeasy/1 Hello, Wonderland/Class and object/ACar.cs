using System;
namespace ClassAndObject
{
    class Car
    {
        double Weight;
        string Color;

        void PrintWeight()
        {
            Console.WriteLine(Weight);
        }
        void PrintColor()
        {
            Console.WriteLine(Color);
        }
    }

}