namespace ClassAndObject
{
    class User
    {
        int Age;
        string Name;

        string GetName()
        {
            return Name;
        }

    }
}