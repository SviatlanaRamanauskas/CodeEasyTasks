using System;

namespace ConsoleInput
{
    public class AccessChecker
    {
        public static void Main(string[] args)
        {
            string name = Console.ReadLine();

            if (name == "Ritchie")
            {
                Console.WriteLine("Access granted");
            }// Write your code here
        }
    }
}
