using System;

namespace Booleans
{
    public class FixNoname
    {
        public static void Main(string[] args)
        {
            bool isNight = false;
            int numberOfModules = 6;
            if (!isNight && (numberOfModules == 6))
            {
                Console.WriteLine("Connect to Noname.");
            }
        }
    }
}
