using System;

namespace Booleans
{
    public class WeatherChecker
    {
        public static void Main(string[] args)
        {
            bool isRaining = false;
            if (!isRaining)
            {
                Console.WriteLine("Go outside.");
            }
        }
    }
}
