using System;

namespace Booleans
{
    class EveryoneLikesKittens
    {
        static void Main(string[] args)
        {
            bool kittensAreNice = true;
            if (kittensAreNice)
            {
                Console.WriteLine("Turn on video with kittens!");
            }
            else
            {
                Console.WriteLine("I'm a dog person");
            }
        }
    }
}