using System;

namespace Booleans
{
    class AreYouAGoodProgrammer
    {     
        static void Main(string[] args)
        {
            bool knowIfStatements = true;
            bool knowBoolType = true;
            if (knowBoolType && knowIfStatements)
            {
                Console.WriteLine("I'm a good programmer!");
            }
        }
    }
}
