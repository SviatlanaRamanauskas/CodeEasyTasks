using System;

namespace Booleans
{
    class ToDanceOrNotToDance
    {     
        static void Main(string[] args)
        {
            bool todayIDance = true;
            if (todayIDance)
            {
                Console.WriteLine("Let's dance");
            }
        }
    }
}
