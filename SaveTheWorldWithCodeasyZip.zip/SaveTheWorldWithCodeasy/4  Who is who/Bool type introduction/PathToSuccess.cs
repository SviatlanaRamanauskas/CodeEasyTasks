using System;

namespace Booleans
{
    class PathToSuccess
    {     
        static void Main(string[] args)
        {
            bool loveWhatYouDo = true;
            bool doWhatYouLove = true;
            if (loveWhatYouDo && doWhatYouLove)
            {
                Console.WriteLine("My path to success");
            }
        }
    }
}
