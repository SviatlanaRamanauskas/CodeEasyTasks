using System;

namespace Methods
{
    class FunctionalModule
    {
        static void Main(string[] args)
        {

        }
        
        static void FromAToF(string command)
        {
            Console.WriteLine($"FromAToF executes {command}.");
        }

        static void FromGToL(string command)
        {
            Console.WriteLine($"FromGToL executes {command}.");
        }

        static void FromMToR(string command)
        {
            Console.WriteLine($"FromMToR executes {command}.");
        }

        static void FromSToZ(string command)
        {
            Console.WriteLine($"FromSToZ executes {command}.");
        }
    }
}