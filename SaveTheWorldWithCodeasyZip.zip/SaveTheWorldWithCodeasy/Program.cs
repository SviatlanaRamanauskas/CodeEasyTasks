﻿using System;

namespace SaveTheWorldWithCodeasy
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I write code as professional programmers do!");
        }
    }
}
